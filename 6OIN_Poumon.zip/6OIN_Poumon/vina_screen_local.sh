#! /bin/bash
FILES="/home/said/Bureau/Said6-25/6OIN_Poumon/*.pdbqt"
for f in $FILES
do
    b=`basename $f .pdbqt`
    echo Processing ligand $b
    mkdir -p $b
    vina --config conf.txt --ligand $f --out ${b}/out.pdbqt
done
